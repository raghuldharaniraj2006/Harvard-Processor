module memory_tb;

reg [7:0]data_in;
reg [8:0] addr_in;
wire [7:0] data_out;

memory dut (data_in,addr_in,data_out);

initial
begin
    data_in=8'b10101010;

end
initial
    $monitor("data %b",data_in);





endmodule
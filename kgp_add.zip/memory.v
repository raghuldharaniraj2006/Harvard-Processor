module memory(data_in,addr_in,data_out);

input  [7:0] data_in;
input [8:0] addr_in;
output [7:0] data_out;

reg[7:0] mem[0:300];


always @ (data_in or addr_in) 
begin
    mem[addr_in] = data_in;
end

assign data_out = mem[addr_in];

endmodule
